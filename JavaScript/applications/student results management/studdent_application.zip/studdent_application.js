let students_data=
[
    {
    id:1,
    name:"Chanikya",
    gender:"Male",
    marks:[55,66,77,88,99],
    },
    {
        id:2,
        name:"vijay",
        gender:"Male",
        marks:[56,86,70,58,90],
    },
    {
    id:3,
    name:"Nayanthara",
    gender:"Female",
    marks:[35,26,67,81,19],
    },

    {
    id:4,
    name:"pooja hegde",
    gender:"Female",
    marks:[51,64,27,68,49],
               
    },
    {   id:5,
        name:"prabhas",
        gender:"Male",
        marks:[50,60,75,45,66],
                    
    },
    {
        id:10,
        name:"dhanush",
        gender:"Male",
        marks:[50,40,47,38,49],
        },
    {
            id:11,
            name:"Allu Arjun",
            gender:"Male",
            marks:[55,66,77,88,99],
    },
    {
        id:143,
        name:"pavan kalyan",
        gender:"Male",
        marks:[10,40,47,38,49],
        },
]

function percentage_calculator(data)
{ let total_marks=0;
    for(let i of data)
    {
        total_marks+=i;
    }    
    return ((total_marks/500)*100);
}

function result_calculator(data)
{
    for(let i of data)
    {
        if(i<35)
        {
            return "Fail"
        }

    }
    return "Pass"
}
    




let dispaly_table_content=document.querySelector("#table-body");

// displaying hole data defualty
 function displaytable(data)
 {
    let result=``
    if(students_data.length>0)
    {
        for(let data of students_data)
        { let res=result_calculator(data.marks)
            let per=percentage_calculator(data.marks);
        result+=`<tr>
        <td>${data.id}</td>
        <td>${data.name}</td>
        <td>${data.gender}</td>
        <td>${per.toFixed(2)} %</td>
        <td>${res}</td>
        </tr>`
        }
    }

    dispaly_table_content.innerHTML=result
}
// displaytable(students_data);



// showing data of passed students
function show_pass()
{ let result=``
    for(let data of students_data)
    {
        let res=result_calculator(data.marks);
        let per=percentage_calculator(data.marks);
        if(res=="Pass")
        {
        result+=`<tr>
        <td>${data.id}</td>
        <td>${data.name}</td>
        <td>${data.gender}</td>
        <td>${per.toFixed(2)} %</td>
        <td>${res}</td>
        </tr>`
        }
    }
    dispaly_table_content.innerHTML=result;
}

// showing detrails of failed students only
function show_fail()
{ let result=``
    for(let data of students_data)
    {
        let res=result_calculator(data.marks);
        let per=percentage_calculator(data.marks);
        if(res=="Fail")
        {
        result+=`<tr>
        <td>${data.id}</td>
        <td>${data.name}</td>
        <td>${data.gender}</td>
        <td>${per.toFixed(2)} %</td>
        <td>${res}</td>
        </tr>`
        }
    }
    dispaly_table_content.innerHTML=result;
}

// showing males students data
function show_male()
{ let result=``
    for(let data of students_data)
    {
        let res=result_calculator(data.marks);
        let per=percentage_calculator(data.marks);
        if(data.gender=="Male")
        {
        result+=`<tr>
        <td>${data.id}</td>
        <td>${data.name}</td>
        <td>${data.gender}</td>
        <td>${per.toFixed(2)} %</td>
        <td>${res}</td>
        </tr>`
        }
    }
    dispaly_table_content.innerHTML=result;
}

// showing females data
function show_female()
{ let result=``
    for(let data of students_data)
    {
        let res=result_calculator(data.marks);
        let per=percentage_calculator(data.marks);
        if(data.gender=="Female")
        {
        result+=`<tr>
        <td>${data.id}</td>
        <td>${data.name}</td>
        <td>${data.gender}</td>
        <td>${per.toFixed(2)} %</td>
        <td>${res}</td>
        </tr>`
        }
    }
    dispaly_table_content.innerHTML=result;
}






 